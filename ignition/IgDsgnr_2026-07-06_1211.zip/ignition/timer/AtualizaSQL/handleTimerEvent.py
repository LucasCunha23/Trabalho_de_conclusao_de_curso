def handleTimerEvent():
	# Pega os valores das tags do OPC
opc_ligada = system.tag.read("[default]Application/FIO/OPC_Ligada").value
opc_bloqueio = system.tag.read("[default]Application/FIO/OPC_Bloqueio").value
opc_contagem_pontos = system.tag.read("[default]Application/FIO/OPC_ContagemPontos").value
opc_pecas_finalizadas = system.tag.read("[default]Application/FIO/OPC_PecasFinalizadas").value

# Query de inserção no banco de dados
query = """
    INSERT INTO eventos_maquina (OPC_Ligada, OPC_Bloqueio, OPC_ContagemPontos, OPC_PecasFinalizadas)
    VALUES (?, ?, ?, ?)
"""

# Parâmetros para a query
params = [opc_ligada, opc_bloqueio, opc_contagem_pontos, opc_pecas_finalizadas]

# Executa a query no banco de dados
system.db.runPrepQuery(query, params)