SELECT
    maquina AS `Maquina`,
    turno_codigo AS `Turno`,
    DATE_FORMAT(data_inicio, '%d/%m/%Y %H:%i:%s') AS `Inicio`,
    DATE_FORMAT(data_fim, '%d/%m/%Y %H:%i:%s') AS `Fim`,

    status AS `Status`,
    celula AS `Celula`,
    operador AS `Operador`,
    numero_op AS `OP`,
    processo AS `Processo`,

    tempo_ligada_s AS `Ligada_s`,
    tempo_produzindo_s AS `Produzindo_s`,
    tempo_parada_s AS `Parada_s`,
    tempo_bloqueada_s AS `Bloqueada_s`,

    operacoes_finalizadas AS `Operacoes_Finalizadas`,
    operacoes_boas AS `Operacoes_Boas`,
    operacoes_reprovadas AS `Operacoes_Reprovadas`,

    pecas_produzidas_ciclo AS `Pecas_Produzidas`,
    pecas_estipuladas_ciclo AS `Pecas_Estipuladas`,
    tempo_ideal_ciclo_ms AS `Tempo_Ideal_Ciclo_ms`,

    COALESCE(principal_motivo_parada, '') AS `Principal_Motivo_Parada`,
    maior_parada_s AS `Maior_Parada_s`,

    disponibilidade_pct AS `Disponibilidade_pct`,
    performance_pct AS `Performance_pct`,
    qualidade_pct AS `Qualidade_pct`,
    oee_pct AS `OEE_pct`

FROM vw_relatorio_pim_turno
WHERE data_inicio >= :data_inicio
  AND data_fim <= :data_fim
ORDER BY data_inicio ASC, turno_codigo ASC, maquina ASC;