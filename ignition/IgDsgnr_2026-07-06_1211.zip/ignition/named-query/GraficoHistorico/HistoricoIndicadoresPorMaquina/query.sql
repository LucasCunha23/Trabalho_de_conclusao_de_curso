SELECT
    calc.data_hora,

    ROUND(calc.disponibilidade * 100, 2) AS disponibilidade,
    ROUND(calc.performance * 100, 2) AS performance,
    ROUND(calc.qualidade * 100, 2) AS qualidade,

    ROUND(
        calc.disponibilidade
        * calc.performance
        * calc.qualidade
        * 100,
        2
    ) AS oee

FROM (
    SELECT
        criado_em AS data_hora,

        COALESCE(
            tempo_produzindo_s
            / NULLIF(tempo_ligada_s, 0),
            0
        ) AS disponibilidade,

        COALESCE(
            (
                (tempo_ideal_ciclo_ms / 1000.0)
                * pecas_produzidas_ciclo
            )
            / NULLIF(tempo_produzindo_s, 0),
            0
        ) AS performance,

        COALESCE(
            operacoes_boas
            / NULLIF(operacoes_finalizadas, 0),
            0
        ) AS qualidade

    FROM pim_turno_maquina

    WHERE maquina = :maquina
      AND criado_em >= :dataInicial
      AND criado_em <= :dataFinal
) AS calc

ORDER BY calc.data_hora;