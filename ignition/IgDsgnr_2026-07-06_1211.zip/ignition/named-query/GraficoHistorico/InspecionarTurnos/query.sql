SELECT
    turno_id,
    maquina,
    criado_em,
    tempo_ligada_s,
    tempo_produzindo_s,
    operacoes_finalizadas,
    operacoes_boas,
    operacoes_reprovadas,
    pecas_produzidas_ciclo
FROM pim_turno_maquina
WHERE maquina = 1
  AND criado_em >= '2026-06-11 00:00:00'
  AND criado_em <  '2026-06-12 00:00:00'
ORDER BY criado_em DESC;