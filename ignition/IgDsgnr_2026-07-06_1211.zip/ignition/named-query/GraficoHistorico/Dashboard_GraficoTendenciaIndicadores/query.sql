SELECT
    calc.data_eixo,
    calc.turno_id,
    calc.maquina,
    :dataInicio AS filtro_inicio,
    :dataFim AS filtro_fim,

    ROUND(calc.disponibilidade * 100, 2) AS disponibilidade,
    ROUND(calc.performance * 100, 2) AS performance,
    ROUND(calc.qualidade * 100, 2) AS qualidade,

    ROUND(
        calc.disponibilidade *
        calc.performance *
        calc.qualidade * 100,
        2
    ) AS oee

FROM (
    SELECT
        turno_id,
        maquina,

        DATE_FORMAT(MIN(criado_em), '%d/%m %H:%i') AS data_eixo,
        MIN(criado_em) AS data_ordem,

        SUM(tempo_produzindo_s) / NULLIF(SUM(tempo_ligada_s), 0) AS disponibilidade,
        SUM(pecas_produzidas_ciclo) / NULLIF(SUM(pecas_estipuladas_ciclo), 0) AS performance,
        SUM(operacoes_boas) / NULLIF(SUM(operacoes_finalizadas), 0) AS qualidade

    FROM pim_turno_maquina

    WHERE maquina = :maquina
      AND criado_em >= :dataInicio
      AND criado_em <= :dataFim

    GROUP BY turno_id, maquina
) calc

ORDER BY calc.data_ordem ASC;