SELECT
    maquina,

    tempo_ligada_s,
    tempo_produzindo_s,
    tempo_parada_s,
    tempo_bloqueada_s,

    operacoes_finalizadas,
    operacoes_boas,
    operacoes_reprovadas,

    pecas_produzidas_ciclo,
    pecas_estipuladas_ciclo,

    tempo_ideal_ciclo_ms,
    ROUND(tempo_ideal_ciclo_ms / 1000.0, 3) AS tempo_ideal_ciclo_s,

    ROUND(
        COALESCE(
            tempo_produzindo_s / NULLIF(tempo_ligada_s, 0),
            0
        ) * 100,
        2
    ) AS disponibilidade_atual,

    ROUND(
        COALESCE(
            (
                (tempo_ideal_ciclo_ms / 1000.0)
                * operacoes_finalizadas
            )
            / NULLIF(tempo_produzindo_s, 0),
            0
        ) * 100,
        2
    ) AS performance_por_tempo_ideal,

    ROUND(
        COALESCE(
            pecas_produzidas_ciclo
            / NULLIF(pecas_estipuladas_ciclo, 0),
            0
        ) * 100,
        2
    ) AS performance_por_meta_ciclo,

    ROUND(
        COALESCE(
            operacoes_boas
            / NULLIF(operacoes_finalizadas, 0),
            0
        ) * 100,
        2
    ) AS qualidade_atual

FROM pim_turno_maquina

WHERE turno_id = (
    SELECT MAX(turno_id)
    FROM pim_turno_maquina
)

ORDER BY maquina;