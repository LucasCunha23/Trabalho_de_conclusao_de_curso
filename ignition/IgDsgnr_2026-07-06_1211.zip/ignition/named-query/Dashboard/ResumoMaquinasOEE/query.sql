SELECT
    calc.turno_id,
    calc.maquina,
    calc.operador,
    calc.numero_op AS numeroOP,
    calc.processo,

    ROUND(calc.disponibilidade * 100, 2) AS disponibilidade,
    ROUND(calc.performance * 100, 2) AS performance,
    ROUND(calc.qualidade * 100, 2) AS qualidade,

    ROUND(
        calc.disponibilidade
        * calc.performance
        * calc.qualidade
        * 100,
        2
    ) AS oee

FROM (
    SELECT
        turno_id,
        maquina,
        operador,
        numero_op,

        CASE
            WHEN maquina BETWEEN 1 AND 7
                THEN 'FREEDOM DX / WORKING SX.DX'

            WHEN maquina BETWEEN 8 AND 12
                THEN 'FREEDOM SX / WORKING SX'

            ELSE 'PROCESSO NÃO CONFIGURADO'
        END AS processo,

        COALESCE(
            tempo_produzindo_s
            / NULLIF(tempo_ligada_s, 0),
            0
        ) AS disponibilidade,

        COALESCE(
            (
                (tempo_ideal_ciclo_ms / 1000.0)
                * pecas_produzidas_ciclo
            )
            / NULLIF(tempo_produzindo_s, 0),
            0
        ) AS performance,

        COALESCE(
            operacoes_boas
            / NULLIF(operacoes_finalizadas, 0),
            0
        ) AS qualidade

    FROM pim_turno_maquina

    WHERE turno_id = (
        SELECT MAX(turno_id)
        FROM pim_turno_maquina
    )
) AS calc

ORDER BY calc.maquina;