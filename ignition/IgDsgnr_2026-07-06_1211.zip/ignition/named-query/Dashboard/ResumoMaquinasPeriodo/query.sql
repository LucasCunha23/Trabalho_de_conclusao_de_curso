SELECT
    calc.maquina,
    calc.processo,
    calc.numeroOP,
    calc.operador,

    ROUND(calc.disponibilidade * 100, 2) AS disponibilidade,
    ROUND(calc.performance * 100, 2) AS performance,
    ROUND(calc.qualidade * 100, 2) AS qualidade,

    ROUND(
        calc.disponibilidade
        * calc.performance
        * calc.qualidade
        * 100,
        2
    ) AS oee

FROM (
    SELECT
        maquina,

        CASE
            WHEN COUNT(DISTINCT processo) = 0 THEN ''
            WHEN COUNT(DISTINCT processo) = 1 THEN MAX(processo)
            ELSE 'Vários processos'
        END AS processo,

        CASE
            WHEN COUNT(DISTINCT numero_op) = 0 THEN ''
            WHEN COUNT(DISTINCT numero_op) = 1 THEN MAX(numero_op)
            ELSE 'Várias OPs'
        END AS numeroOP,

        CASE
            WHEN COUNT(DISTINCT operador) = 0 THEN ''
            WHEN COUNT(DISTINCT operador) = 1 THEN MAX(operador)
            ELSE 'Vários operadores'
        END AS operador,

        COALESCE(
            SUM(tempo_produzindo_s)
            / NULLIF(SUM(tempo_ligada_s), 0),
            0
        ) AS disponibilidade,

        COALESCE(
            SUM(
                (tempo_ideal_ciclo_ms / 1000.0)
                * operacoes_finalizadas
            )
            / NULLIF(SUM(tempo_produzindo_s), 0),
            0
        ) AS performance,

        COALESCE(
            SUM(operacoes_boas)
            / NULLIF(SUM(operacoes_finalizadas), 0),
            0
        ) AS qualidade

    FROM vw_relatorio_pim_turno

    WHERE data_inicio >= :dataInicial
     AND data_inicio < DATE_ADD(:dataFinal, INTERVAL 1 DAY)
     AND status = 'FINALIZADO'

    GROUP BY maquina
) AS calc

ORDER BY calc.maquina;