INSERT INTO fabrica.turnos_producao
(
    turno_codigo,
    celula,
    data_inicio,
    data_fim,
    status
)
VALUES
(
    :turno_codigo,
    :celula,
    :data_inicio,
    :data_fim,
    'FINALIZADO'
);