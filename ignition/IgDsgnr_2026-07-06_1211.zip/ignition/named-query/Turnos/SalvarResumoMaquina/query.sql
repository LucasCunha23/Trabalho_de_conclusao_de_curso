INSERT INTO fabrica.pim_turno_maquina
(
    turno_id,
    maquina,
    operador,
    numero_op,
    processo,
    tempo_ligada_s,
    tempo_produzindo_s,
    tempo_parada_s,
    tempo_bloqueada_s,
    operacoes_finalizadas,
    operacoes_boas,
    operacoes_reprovadas,
    pecas_produzidas_ciclo,
    pecas_estipuladas_ciclo,
    tempo_ideal_ciclo_ms
)
VALUES
(
    :turno_id,
    :maquina,
    :operador,
    :numero_op,
    :processo,
    :tempo_ligada_s,
    :tempo_produzindo_s,
    :tempo_parada_s,
    :tempo_bloqueada_s,
    :operacoes_finalizadas,
    :operacoes_boas,
    :operacoes_reprovadas,
    :pecas_produzidas_ciclo,
    :pecas_estipuladas_ciclo,
    :tempo_ideal_ciclo_ms
)
ON DUPLICATE KEY UPDATE
    operador = VALUES(operador),
    numero_op = VALUES(numero_op),
    processo = VALUES(processo),
    tempo_ligada_s = VALUES(tempo_ligada_s),
    tempo_produzindo_s = VALUES(tempo_produzindo_s),
    tempo_parada_s = VALUES(tempo_parada_s),
    tempo_bloqueada_s = VALUES(tempo_bloqueada_s),
    operacoes_finalizadas = VALUES(operacoes_finalizadas),
    operacoes_boas = VALUES(operacoes_boas),
    operacoes_reprovadas = VALUES(operacoes_reprovadas),
    pecas_produzidas_ciclo = VALUES(pecas_produzidas_ciclo),
    pecas_estipuladas_ciclo = VALUES(pecas_estipuladas_ciclo),
    tempo_ideal_ciclo_ms = VALUES(tempo_ideal_ciclo_ms);